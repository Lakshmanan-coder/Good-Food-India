<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlanPictures extends Model
{
    //
}
