   <!-- COMMON SCRIPTS -->
   <script src="/js/common_scripts.min.js"></script>
   <script src="/js/slider.js"></script>
   <script src="/js/common_func.js"></script>
   {{-- <script src="assets/validate.js"></script> --}}
   @yield('extra_scripts')