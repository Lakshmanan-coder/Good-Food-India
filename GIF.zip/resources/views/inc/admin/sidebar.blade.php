<ul>
    <li class="menu-title">Main</li>

    <li>
        <a href="/admin" class="waves-effect"><i class="ti-home"></i><span> Dashboard </span></a>
    </li>

   

    {{-- <li class="has_sub">
        <a href="javascript:void(0);" class="waves-effect"><i class="ti-layout"></i><span> Orders </span><span class="float-right"><i class="mdi mdi-plus"></i></span></a>
        <ul class="list-unstyled">
            <li><a href="/admin/orders">Manage Orders</a></li>
        </ul>
    </li> --}}

    <li class="has_sub">
        <a href="javascript:void(0);" class="waves-effect"><i class="ti-files"></i><span> Plans </span><span class="float-right"><i class="mdi mdi-plus"></i></span></a>
        <ul class="list-unstyled">
            <li><a href="/admin/add-plan">Add Plan</a></li>
            <li><a href="/admin/view-plans">View Plan</a></li>
           
        </ul>
    </li>
     <li>
        <a href="/admin/users" class="waves-effect"><i class="ti-user"></i><span> Users </span></a>
    </li>
     <li>
        <a href="/admin/calender" class="waves-effect"><i class="ti-calendar"></i><span> Calendar </span></a>
    </li>
     <li>
        <a href="/admin/subscriptions" class="waves-effect"><i class="ti-layout-slider-alt"></i><span> Subscriptions </span></a>
    </li>
</ul>