   <!-- COMMON SCRIPTS -->
   <script src="/js/common_scripts.min.js"></script>
   <script src="/js/slider.js"></script>
   <script src="/js/common_func.js"></script>
   
   <?php echo $__env->yieldContent('extra_scripts'); ?><?php /**PATH C:\xampp\htdocs\GIF\resources\views/inc/user/scripts.blade.php ENDPATH**/ ?>