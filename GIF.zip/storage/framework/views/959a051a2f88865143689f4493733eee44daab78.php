
<?php if(session('success')): ?>
<script>swal('Good Job !',"<?php echo session('success') ?>" , 'success');</script>
<?php endif; ?>
<?php if(session('error')): ?>
<script>swal('Oops !',"<?php echo session('error') ?>" , 'error');</script>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\GIF\resources\views/inc/messages.blade.php ENDPATH**/ ?>