<header class=" <?php echo $__env->yieldContent("header_type"); ?> clearfix ">

    <div class="container">
    <div id="logo">
        <a href="/">
            <img src="/img/logo.svg" width="140" height="35" alt="" class="logo_normal">
            <img src="/img/logo_sticky.svg" width="140" height="35" alt="" class="logo_sticky">
        </a>
    </div>
    <?php if(auth()->guard()->guest()): ?>
    <ul id="top_menu">
        <li><a href="#sign-in-dialog" id="sign-in" class="login">Sign In</a></li>
    </ul>

    <?php else: ?>
    <ul id="top_menu">
        <li><a href="<?php echo e(route('logout')); ?>" id="sign-in" class="login" onclick="event.preventDefault();
            document.getElementById('logout-form').submit();">Sign In</a></li>
    </ul>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>

    <?php endif; ?>
    <!-- /top_menu -->
    <a href="#0" class="open_close">
        <i class="icon_menu"></i><span>Menu</span>
    </a>
    <nav class="main-menu">
        <div id="header_menu">
            <a href="#0" class="open_close">
                <i class="icon_close"></i><span>Menu</span>
            </a>
            <a href="/"><img src="/img/logo.svg" width="140" height="35" alt=""></a>
        </div>
        <ul>
            <li class="submenu">
                <a href="/" class="show-submenu">Home</a>
            
            </li>
            <li class="submenu">
                <a href="/plans" class="show-submenu">Plan</a>
        
            </li>
            <?php if(auth()->guard()->check()): ?>
            <li class="submenu">
                <a href="/profile" class="show-submenu">Profile</a>
            
            </li>
            
            <li><a href="/calender">Calendar</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</div>
</header><?php /**PATH C:\xampp\htdocs\GIF\resources\views/inc/user/navbar.blade.php ENDPATH**/ ?>