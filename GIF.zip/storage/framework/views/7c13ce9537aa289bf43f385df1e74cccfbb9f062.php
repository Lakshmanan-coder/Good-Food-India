
<?php $__env->startSection('header_type','header element_to_stick'); ?>

<?php $__env->startSection('content'); ?>
      
 <!--hero section-->
 <div class="hero_single inner_pages background-image" data-background="url(img/hero_submit.jpg)">
    <div class="opacity-mask" data-opacity-mask="rgba(0, 0, 0, 0.6)">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-9 col-lg-10 col-md-8">
                    <h1>Attract New Customers</h1>
                    <p>More bookings from diners around the corner</p>
                </div>
            </div>
            <!-- /row -->
        </div>
    </div>
</div>
<!-- /hero_single -->
    <!-- View plans -->
<main>
	<div class="container margin_60_40">
        

        <div class="row">
            <div class="col-12">
                <div class="main_title version_2">
                    <span><em></em></span>
                    <h2>All Plans</h2>
                    
                    
                </div>
            </div>
            <?php if(count($plans)>0): ?>
            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $menus=App\Menu::where('plan_id',$plan->id)->get(); $planpicture=App\PlanPictures::where('plan_id',$plan->id)->first(); ?>
            <div class="col-md-6">
                <div class="list_home">
                    <ul>
                        <li>
                            <a href="/plan-detail/<?php echo e($plan->id); ?>">
                                <figure>
                                    <img src="/storage/plan_picture/<?php echo e($planpicture->path); ?>" data-src="/storage/plan_picture/<?php echo e($planpicture->path); ?>" alt=""
                                        class="lazy" style=" ">
                                </figure>
                                
                                <em><?php echo e(count($menus)); ?> Delicious Menu</em>
                                <h3><?php echo e($plan->plan_name); ?></h3>
                                <small></small>
                                <ul>
                                    
                                    <li>Price Rs. <?php echo e($plan->one_price); ?> - <?php echo e($plan->month_price); ?></li>

                                </ul>
                            </a>
                        </li>
                     
                  
                    </ul>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </div>
        <!-- /row -->
        <p class="text-center d-block d-md-block d-lg-none"><a href="grid-listing-filterscol.html" class="btn_1">View All</a></p>
        <!-- /button visibile on tablet/mobile only -->

     
       
    </div>
    <!-- /bg_gray -->
</main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GIF\resources\views/user/plans.blade.php ENDPATH**/ ?>