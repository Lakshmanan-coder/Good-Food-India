
<?php $__env->startSection('header_type','header element_to_stick'); ?>

<?php $__env->startSection('extra_styles'); ?>
       <!-- SPECIFIC CSS -->
       <link href="/css/detail-page.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!--hero section-->
    <div class="hero_single inner_pages background-image" data-background="url(/img/hero_submit.jpg)">
        <div class="opacity-mask" data-opacity-mask="rgba(0, 0, 0, 0.6)">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-9 col-lg-10 col-md-8">
                        <h1><?php echo e($plan->plan_name); ?></h1>
                        <p>More bookings from diners around the corner</p>
                    </div>
                </div>
                <!-- /row -->
            </div>
        </div>
    </div>
    <!-- /hero_single -->


<main>
		
    <div class="container margin_detail">
        <div class="row">
            
            <div class="col-lg-8">
                <div class="detail_page_head clearfix margin-2rem">
                    <div class="breadcrumbs">
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Plans</a></li>
                            <li><?php echo e($plan->plan_name); ?></li>
                        </ul>
                    </div>
                    <div class="title">
                        <h1><?php echo e($plan->plan_name); ?></h1>
                        <ul class="tags">
                            <?php
                            $results= explode(",",$plan->tags);
                            ?>
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="#0"><?php echo e($result); ?></a></li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    
                </div>
                <!-- /detail_page_head -->

                <div class="owl-carousel owl-theme carousel_1 magnific-gallery">
                    <?php if(count($planpictures)>0): ?>
                        <?php $__currentLoopData = $planpictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                        <a  title="Photo title" data-effect="mfp-zoom-in"><img src="/storage/plan_picture/<?php echo e($picture->path); ?>" alt=""></a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  
                   
                </div>
                <!-- /carousel -->

                <div class="tabs_detail">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a id="tab-A" href="#pane-A" class="nav-link active" data-toggle="tab" role="tab">Information</a>
                        </li>
                        <li class="nav-item">
                            <a id="tab-B" href="#pane-B" class="nav-link" data-toggle="tab" role="tab">Prices</a>
                        </li>
                    </ul>

                    <div class="tab-content" role="tablist">
                        <div id="pane-A" class="card tab-pane fade show active" role="tabpanel" aria-labelledby="tab-A">
                            <div class="card-header" role="tab" id="heading-A">
                                <h5>
                                    <a class="collapsed" data-toggle="collapse" href="#collapse-A" aria-expanded="true" aria-controls="collapse-A">
                                        Information
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-A" class="collapse" role="tabpanel" aria-labelledby="heading-A">
                                <div class="card-body info_content">
                                    <h2><?php echo e($plan->plan_name); ?> Menu</h2>
                                    <?php if(count($menus)>0): ?>
                                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="menu_item">
                                            <h4><?php echo e($menu->title); ?></h4>
                                            <p><?php echo e($menu->description); ?></p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                   
                                   
                                    <hr>
                                    
                                    <!-- /content_more -->
                                   
                                    <div class="add_bottom_45"></div>

                                    
                                   
                                    
                                    

                                    <!-- /special_offers -->

                                  
                                </div>
                            </div>
                        </div>
                        <div id="pane-B" class="card tab-pane fade show " role="tabpanel" aria-labelledby="tab-B">
                            <div class="card-header" role="tab" id="heading-B">
                                <h5>
                                    <a class="collapsed" data-toggle="collapse" href="#collapse-B" aria-expanded="true" aria-controls="collapse-A">
                                        Prices
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-B" class="collapse" role="tabpanel" aria-labelledby="heading-B">
                                <div class="card-body info_content">
                                   
                                    <div class="card">
                                        <div class="card-body">
                                            <table class="table table-bordered">
                                                <tr>
                                                    <th>1 Day</th>
                                                    <td>Rs. <?php echo e($plan->one_price); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>7 Days</th>
                                                    <td>Rs. <?php echo e($plan->seven_price); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>15 Days</th>
                                                    <td>Rs. <?php echo e($plan->fifteen_price); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>30 Days</th>
                                                    <td>Rs. <?php echo e($plan->month_price); ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                   
                                   
                                    <hr>
                                    
                                    <!-- /content_more -->
                                   
                                    <div class="add_bottom_45"></div>

                                    
                                   
                                    
                                    

                                    <!-- /special_offers -->

                                  
                                </div>
                            </div>
                        </div>
                        <!-- /tab -->

                    </div>
                    <!-- /tab-content -->
                </div>
                <!-- /tabs_detail -->
            </div>
            <!-- /col -->

            <div class="col-lg-4" id="sidebar_fixed">
                <div class="box_booking " style="margin-top:140px">
                    <div class="head">
                        <h3>Subscribe your Plan</h3>
                        
                    </div>
                    <!-- /head -->
                    <div class="main">
                       <form action="/subscribe" method="post">
                        <?php echo csrf_field(); ?>
                       <input type="hidden" value="<?php echo e($plan->id); ?>" name="plan_id">
                        <button type="submit" class="btn_1 full-width mb_5">Subscribe Now</button>
                        </form>
                    </div>
                </div>
                <!-- /box_booking -->
                

                <div class="box_booking " >
                    <div class="head">
                        <h3>Recent Plans</h3>
                        
                    </div>
                    <!-- /head -->
                    <div class="main">
                        <?php if(count($plans=App\Plans::orderBy('id','desc')->paginate(3))): ?>
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $menus=App\Menu::where('plan_id',$plan->id)->get(); $planpicture=App\PlanPictures::where('plan_id',$plan->id)->first(); ?>
    
                        <div class="list_home">
                            <ul>
                                <li>
                                    <a href="/plan-detail/<?php echo e($plan->id); ?>">
                                        <figure>
                                            <img src="/storage/plan_picture/<?php echo e($planpicture->path); ?>" data-src="/storage/plan_picture/<?php echo e($planpicture->path); ?>" alt=""
                                                class="lazy" style=" ">
                                        </figure>
                                        
                                        <em><?php echo e(count($menus)); ?> Delicious Menu</em>
                                        <h3><?php echo e($plan->plan_name); ?></h3>
                                        <small></small>
                                        <ul>
                                            
                                        <li>Price Rs. <?php echo e($plan->one_price); ?> - <?php echo e($plan->month_price); ?></li>
                                        </ul>
                                    </a>
                                </li>
                             
                          
                            </ul>
                        </div>
        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </div>
                </div>

            
               

            </div>

        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
    
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GIF\resources\views/user/plan-detail.blade.php ENDPATH**/ ?>