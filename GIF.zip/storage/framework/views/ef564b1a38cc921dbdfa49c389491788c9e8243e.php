
<?php $__env->startSection('pagetitle','View Plans'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">

    <div class="">
        <div class="page-header-title">
            <h4 class="page-title"><?php echo $__env->yieldContent('pagetitle'); ?></h4>
        </div>
    </div>

   
    <div class="page-content-wrapper ">

        <div class="container-fluid">

         
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">

                            <h4 class="m-b-30 m-t-0">View Plans</h4>

                            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; width: 100%;">
                                <thead>
                                <tr>
                                    <th></th>
                                    <th>Pack name</th>
                                    <th>Tags</th>
                                    <th>1 Day Price</th>
                                    <th>7 Days Price</th>
                                    <th>15 Days Price</th>
                                    <th>30 Days Price</th>
                                    <th>Menu items</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                   
                                    <?php if(count($plans)>0): ?>
                                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $menus=App\Menu::where('plan_id',$plan->id)->get(); $planpicture=App\PlanPictures::where('plan_id',$plan->id)->first(); ?>

                                            <tr>
                                            <td class="text-center"><img src="/storage/plan_picture/<?php echo e($planpicture->path); ?>" class="img img-thumbnail img-responsive img-circle" style="height:50px; width:50px;" alt=""></td>
                                                <td><?php echo e($plan->plan_name); ?></td>
                                                <td><?php echo e($plan->tags); ?></td>
                                                <td><?php echo e($plan->one_price); ?></td>
                                                <td><?php echo e($plan->seven_price); ?></td>
                                                <td><?php echo e($plan->fifteen_price); ?></td>
                                                <td><?php echo e($plan->month_price); ?></td>
                                                <td><?php echo e(count($menus)); ?></td>
                                                <td>
                                                    <a href="view-plan-detail/<?php echo e($plan->id); ?>" class="btn btn-primary">View Detail</a>
                                                </td>
                                            </tr>


                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>



                               
                            
                               
                               
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>

            </div> <!-- End Row -->

            <!-- end row -->


</div><!-- container-fluid -->

</div> <!-- Page content Wrapper -->



</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GIF\resources\views/admin/plans/ViewPlans.blade.php ENDPATH**/ ?>