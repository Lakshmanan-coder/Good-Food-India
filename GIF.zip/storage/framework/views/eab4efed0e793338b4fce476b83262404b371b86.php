
<?php $__env->startSection('header_type','header_in'); ?>
<?php $__env->startSection('extra_styles'); ?>
<!-- SPECIFIC CSS -->
<link href="/css/home.css" rel="stylesheet">
<link href="/css/Calender.css" rel="stylesheet">

<link href="/assets/plugins/fullcalendar/css/fullcalendar.min.css" rel="stylesheet" />
<style>
  .fc-content {
    background: #589442;
    border: #589442;
    color: #fff;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main>

    <div id='calendar'></div>
</main>
<?php
$data=json_encode($datas)    

?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_scripts'); ?>
<script src="/assets/plugins/jquery-ui/jquery-ui.min.js"></script>
<script src="/assets/plugins/moment/moment.js"></script>
<script src='/assets/plugins/fullcalendar/js/fullcalendar.min.js'></script>
      <!--specific script for calender-->
      

            <?php
            echo "<script>
                const events=";
                echo $data;
                echo"</script>";
    ?>

    
    <script>
        $('#calendar').fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'month,basicWeek,basicDay'
            },
            editable: false,
            events:events
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GIF\resources\views/user/calender.blade.php ENDPATH**/ ?>