<!doctype html>
<html lang="en">

<head>
<?php echo $__env->make('inc.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="fixed-left">
<?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Begin page -->
    <div id="wrapper">

        <!-- Top Bar Start -->
        <div class="topbar">
            <!-- LOGO -->
            <div class="topbar-left">
                <div class="text-center">
                    <a href="/admin" class="logo"><img src="/assets/images/logo-dark.png" alt="" height="24"></a>
                    <a href="/admin" class="logo-sm"><img src="/assets/images/logo-sm.png" alt="" height="28"></a>
                </div>
            </div>
            <!-- Button mobile view to collapse sidebar menu -->

            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <ul class="list-inline menu-left mb-0">
                        <li class="float-left">
                            <button class="button-menu-mobile open-left waves-light waves-effect">
                                <i class="mdi mdi-menu"></i>
                            </button>
                        </li>
                        
                    </ul>

                    <ul class="nav navbar-right float-right list-inline">
                        
                        <li class="d-none d-sm-block">
                            <a href="#" id="btn-fullscreen" class="waves-effect waves-light notification-icon-box"><i class="fas fa-expand"></i></a>
                        </li>

                        <li class="dropdown">
                            <a href="" class="dropdown-toggle profile waves-effect waves-light" data-toggle="dropdown" aria-expanded="true">
                                <img src="/assets/images/users/avatar-1.jpg" alt="user-img" class="rounded-circle">
                                <span class="profile-username">
                                        <?php echo e(Auth::user()->name); ?> <span class="mdi mdi-chevron-down font-15"></span>
                                </span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="/logout" onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();" class="dropdown-item"> Logout</a></li>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- Top Bar End -->

        <!-- ========== Left Sidebar Start ========== -->

        <div class="left side-menu">
            <div class="sidebar-inner slimscrollleft">

                <div class="user-details">
                    <div class="text-center">
                        <img src="/assets/images/users/avatar-1.jpg" alt="" class="rounded-circle img-thumbnail">
                    </div>
                    <div class="user-info">
                        <div class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><?php echo e(Auth::user()->name); ?></a>
                            <ul class="dropdown-menu" >
                                <li><a href="javascript:void(0)" class="dropdown-item" onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();"> Logout</a></li>
                            </ul>
                        </div>

                    </div>
                </div>
                <!--- Divider -->

                <div id="sidebar-menu">
                    <?php echo $__env->make('inc.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="clearfix"></div>
            </div>
            <!-- end sidebarinner -->
        </div>
        <!-- Left Sidebar End -->

        <!-- Start right Content here -->

        <div class="content-page">
            <!-- Start content -->
            <?php echo $__env->yieldContent('content'); ?>

        </div> <!-- Page content Wrapper -->

        </div>
        <!-- content -->

        <footer class="footer">
            ©2020 Good Indian Food <span class="d-none d-md-inline-block"> - Designed by Nyx Wolves</span>
        </footer>

    </div>
    <!-- End Right content here -->

    </div>
    <!-- END wrapper -->

    <!-- jQuery  -->
<?php echo $__env->make('inc.admin.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\GIF\resources\views/layouts/admin.blade.php ENDPATH**/ ?>