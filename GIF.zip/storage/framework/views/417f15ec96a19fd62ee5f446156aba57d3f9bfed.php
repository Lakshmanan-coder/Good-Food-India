
<?php $__env->startSection('pagetitle','View Subscriptions'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">

    <div class="">
        <div class="page-header-title">
            <h4 class="page-title"><?php echo $__env->yieldContent('pagetitle'); ?></h4>
        </div>
    </div>

   
    
    <div class="page-content-wrapper ">

        <div class="container-fluid">


            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-8">
                                    <h4 class="m-b-30 m-t-0">View Subscription Detail</h4>
                                </div>
                                <div class="col-sm-4 text-right">
                                </div>
                            </div>



                            <hr>

                            
                        <div class="row">
                           
                            
                            <div class="col-sm-12">
                                <table id="datatable-responsive" class=" datatable-responsive table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; width: 100%;">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Phone Number</th>
                                        <th>Pack Name</th>
                                        <th>Duration</th>
                                        <th>Address</th>
                                        <th>Payment Id</th>
                                        <th>Price</th>
                                        <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(count($subscribes)>0): ?>
                                        <?php $__currentLoopData = $subscribes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscribe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php
                                         $plan=App\Plans::find($subscribe->plan_id);
                                         $user=App\User::find($subscribe->user_id);
                                        $menus=App\Menu::where('plan_id',$subscribe->plan_id)->get();
                                         $planpicture=App\PlanPictures::where('plan_id',$subscribe->plan_id)->first();
                                         ?>


                                    <tr>
                                    <td class="text-center"><img src="/storage/profile_picture/<?php echo e($user->profile_picture); ?>" class="img  img-responsive img-circle" style="height:30px; width: 30px;"></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->phoneno); ?></td>
                                        <td><?php echo e($plan->plan_name); ?></td>
                                        <td><?php echo e($subscribe->duration); ?> Days</td>
                                        <td><?php echo e($subscribe->doorno); ?>, <?php echo e($subscribe->street); ?>, <?php echo e($subscribe->city); ?>, <?php echo e($subscribe->postelcode); ?></td>
                                        <td><?php echo e($subscribe->payment_id); ?></td>
                                        <td>Rs. <?php echo e($subscribe->totalamount); ?></td>
                                        <td>
                                        <a href="view-subscription-detail/<?php echo e($subscribe->id); ?>" class="btn btn-primary">View Subscription</a>
                                        
                                        </td>
                                    </tr>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>


                                    
                              

                                  
                                   
                                    </tbody>
                                </table>
                            </div>
                        </div>
                         


                            <hr>

                           
                         




                           


                        </div>
                    </div>
                </div>

            </div> <!-- End Row -->

            <!-- end row -->


        </div><!-- container-fluid -->

    </div> <!-- Page content Wrapper -->


</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_scripts'); ?>
<script>
    //Success Message
    $('.del-btn').click(function () {
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#5eed6a",
            cancelButtonColor: "#6cbafa",
            confirmButtonText: "Yes, delete it!"
        }).then(function (result) {
            if (result.value) {
                Swal.fire("Deleted!", "Your Subscriptions has been deleted.", "success");
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GIF\resources\views/admin/subscriptions/ViewSubscriptions.blade.php ENDPATH**/ ?>